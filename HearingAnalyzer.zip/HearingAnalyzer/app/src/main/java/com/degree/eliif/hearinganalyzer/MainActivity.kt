package com.degree.eliif.hearinganalyzer

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {


    fun click(view: View?) {
        val wave = PlayWave()
        wave.setWave(frequencyInput.text.toString().toInt())
        toggleButton.setOnCheckedChangeListener{_,
            isChecked ->
            if (isChecked) wave.start() else wave.stop()
            println(toggleButton.isChecked)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

}
